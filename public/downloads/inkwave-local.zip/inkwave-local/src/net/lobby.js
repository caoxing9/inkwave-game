// 联机大厅（中文界面）：创建/加入房间、选队伍和武器、房主设置地图/时长/机器人难度、查看每个人的连接状态。
import { G } from '../core/ctx.js';
import { WEAPONS, WEAPON_ORDER, MAPS, DIFFICULTY } from '../config.js';
import { LanClient, serverAvailable } from './lan.js';
import { NetSession } from './session.js';

const WEAPON_ZH = { shooter: '喷溅枪', roller: '滚筒刷', charger: '蓄力狙', blaster: '爆破枪' };
const MAP_ZH = { tidewater: '潮汐广场', kelpline: '海带码头', sunset: '黄昏潮汐广场' };
const DIFF_ZH = { easy: '轻松', normal: '普通', hard: '困难' };
const TEAM_ZH = ['蓝方', '红方'];

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export class Lobby {
  constructor(game) {
    this.game = game;
    this.client = null; this.session = null;
    this.el = document.createElement('div');
    this.el.className = 'iwl hidden';
    document.body.appendChild(this.el);
    this.el.addEventListener('keydown', (e) => e.stopPropagation());
    this._renderT = 0;
  }

  get inRoom() { return !!this.client && !this.client.closed; }

  async open() {
    this.el.classList.remove('hidden');
    if (this.inRoom) return this._room();
    this.el.innerHTML = `<div class="iwl-card"><h2>联机对战</h2><p class="iwl-muted">正在检查联机服务器…</p></div>`;
    this.serverOk = await serverAvailable();
    this._entry();
  }
  hide() { this.el.classList.add('hidden'); }

  _profile() { return this.game.api.getProfile(); }
  _weapon() { return this.game.api.getLoadout().weapon; }

  // ---------------------------------------------------------------- 入口
  _entry(error = '') {
    const p = this._profile();
    const code = (location.hash.match(/room=(\w+)/) || [])[1] || '';
    this.el.innerHTML = `
      <div class="iwl-card">
        <h2>联机对战 <small>局域网</small></h2>
        ${this.serverOk ? `<p class="iwl-muted">和同一网络的朋友一起玩：一人创建房间，把房间码告诉其他人。最多 8 人，空位由机器人补齐。</p>` :
        `<div class="iwl-warn"><b>没有检测到联机服务器。</b><br>请在一台电脑上运行 <code>node server.mjs</code>，然后所有人用浏览器打开终端里显示的局域网地址（例如 <code>http://192.168.1.5:3000</code>）。</div>`}
        <label class="iwl-field"><span>昵称</span><input id="iwl-name" maxlength="16" value="${esc(p.name || '玩家')}"></label>
        <label class="iwl-field"><span>武器</span>${this._weaponSelect(this._weapon())}</label>
        <div class="iwl-row">
          <button class="iwl-btn iwl-primary" id="iwl-create" ${this.serverOk ? '' : 'disabled'}>创建房间</button>
        </div>
        <div class="iwl-row">
          <input id="iwl-code" class="iwl-code" maxlength="4" placeholder="房间码" value="${esc(code)}">
          <button class="iwl-btn" id="iwl-join" ${this.serverOk ? '' : 'disabled'}>加入房间</button>
        </div>
        ${error ? `<p class="iwl-error">${esc(error)}</p>` : ''}
        <div class="iwl-row iwl-end"><button class="iwl-btn iwl-ghost" id="iwl-back">返回</button></div>
      </div>`;
    const $ = (id) => this.el.querySelector('#' + id);
    const name = () => { const n = $('iwl-name').value.trim() || '玩家'; this.game.api.setProfileName(n); return n; };
    $('iwl-weapon').onchange = (e) => this.game.api.setLoadout({ weapon: e.target.value });
    $('iwl-back').onclick = () => { this.hide(); this.game.menus?.show('main'); };
    $('iwl-create').onclick = () => this._connect(() => LanClient.create(name(), this._weapon()));
    $('iwl-join').onclick = () => {
      const c = $('iwl-code').value.trim().toUpperCase();
      if (!c) return this._entry('请输入房间码');
      this._connect(() => LanClient.join(c, name(), this._weapon()));
    };
    $('iwl-code').onkeydown = (e) => { if (e.key === 'Enter') $('iwl-join').click(); };
  }

  _weaponSelect(cur) {
    return `<select id="iwl-weapon">${WEAPON_ORDER.map((w) => `<option value="${w}" ${w === cur ? 'selected' : ''}>${WEAPON_ZH[w]}（${esc(WEAPONS[w].name)}）</option>`).join('')}</select>`;
  }

  async _connect(fn) {
    this.el.querySelectorAll('button').forEach((b) => (b.disabled = true));
    try {
      this.client = await fn();
    } catch (e) { return this._entry(e.message); }
    this.session = new NetSession(this.client);
    this.client.onRoom = () => this._schedule();
    this.client.onStatus = () => this._schedule();
    this.client.onError = (msg, fatal) => {
      if (fatal) { this._drop(); if (G.mode === 'match') this.game.quitToMenu(); this.open().then(() => this._entry(msg)); }
      else this._toast(msg);
    };
    this.session.on((d, from) => {
      if (d.t === 'start' && !this.client.isHost && from === this.client.room.host) this._launch(d);
      if (d.t === 'host-left') { this._toast('房主已离开，对局结束'); this._drop(); this.game.quitToMenu(); }
    });
    history.replaceState(null, '', '#room=' + this.client.code);
    this._room();
  }

  _schedule() {
    if (this.el.classList.contains('hidden')) return;
    const now = performance.now();
    if (now - this._renderT < 150) { clearTimeout(this._rt); this._rt = setTimeout(() => this._room(), 160); return; }
    this._renderT = now;
    this._room();
  }

  // ---------------------------------------------------------------- 房间
  _room() {
    const c = this.client;
    if (!c || c.closed) return this._entry();
    if (this.el.classList.contains('hidden')) return;
    const room = c.room, s = room.settings || {};
    const st = new Map(c.status().map((x) => [x.id, x]));
    const me = room.members.find((m) => m.id === c.id);
    const host = c.isHost;
    const allOk = c.allConnected();
    const col = (t) => {
      const list = room.members.filter((m) => m.team === t);
      const rows = list.map((m) => {
        const x = st.get(m.id);
        let conn = '';
        if (m.id === c.id) conn = '<em class="iwl-self">你</em>';
        else if (!host && m.id !== room.host) conn = '<em class="iwl-muted">经房主</em>';
        else if (x) conn = `<em class="iwl-conn iwl-conn--${x.via}" title="${esc(x.stage)}">${x.via === 'direct' ? '直连' : x.via === 'relay' ? '中转' : '连接中…'}${x.ping != null ? ` · ${x.ping}ms` : ''}</em>`;
        return `<li><b>${esc(m.name)}</b>${m.id === room.host ? '<i class="iwl-host">房主</i>' : ''}<span>${WEAPON_ZH[m.weapon] || ''}</span>${conn}</li>`;
      }).join('');
      const bots = Math.max(0, 4 - list.length);
      return `<div class="iwl-team iwl-team--${t}"><h3>${TEAM_ZH[t]} <small>${list.length} 人${bots ? ` + ${bots} 机器人` : ''}</small></h3><ul>${rows || '<li class="iwl-muted">（全部由机器人补位）</li>'}</ul></div>`;
    };
    const opt = (obj, cur, zh) => Object.keys(obj).map((k) => `<option value="${k}" ${k === String(cur) ? 'selected' : ''}>${zh[k] || k}</option>`).join('');
    const mapOpts = MAPS.map((m) => `<option value="${m.id}" ${m.id === s.mapId ? 'selected' : ''}>${MAP_ZH[m.id] || m.name}</option>`).join('');
    const addr = `${location.protocol}//${location.host}/#room=${room.code}`;
    this.el.innerHTML = `
      <div class="iwl-card iwl-wide">
        <div class="iwl-head">
          <h2>房间 <span class="iwl-roomcode">${room.code}</span></h2>
          <div class="iwl-muted">把房间码或链接发给朋友：<code>${esc(addr)}</code> <button class="iwl-btn iwl-small" id="iwl-copy">复制</button></div>
        </div>
        <div class="iwl-teams">${col(0)}${col(1)}</div>
        <div class="iwl-row iwl-opts">
          <label>你的队伍 <button class="iwl-btn iwl-small" id="iwl-switch">换到${TEAM_ZH[me && me.team === 0 ? 1 : 0]}</button></label>
          <label>武器 ${this._weaponSelect(me?.weapon || this._weapon())}</label>
        </div>
        <div class="iwl-row iwl-opts">
          <label>地图 <select id="iwl-map" ${host ? '' : 'disabled'}>${mapOpts}</select></label>
          <label>时长 <select id="iwl-dur" ${host ? '' : 'disabled'}><option value="90" ${s.duration === 90 ? 'selected' : ''}>90 秒</option><option value="180" ${s.duration === 180 ? 'selected' : ''}>3 分钟</option></select></label>
          <label>机器人 <select id="iwl-diff" ${host ? '' : 'disabled'}>${opt(DIFFICULTY, s.difficulty, DIFF_ZH)}</select></label>
        </div>
        <div class="iwl-row iwl-end">
          <button class="iwl-btn iwl-ghost" id="iwl-leave">离开房间</button>
          ${host ? `<button class="iwl-btn iwl-primary" id="iwl-start" ${allOk ? '' : 'disabled'}>${allOk ? '开始对战' : '等待所有人连接…'}</button>`
      : `<span class="iwl-muted">${room.started ? '对战进行中…' : '等待房主开始…'}</span>`}
        </div>
        <p class="iwl-tip">操作：WASD 移动 · 鼠标瞄准 · 左键射击 · Shift 潜墨 · 空格跳 · 右键/E 炸弹 · F/Q 大招 · Tab 地图 · Esc 菜单（联机时比赛不会暂停）</p>
      </div>`;
    const $ = (id) => this.el.querySelector('#' + id);
    $('iwl-copy').onclick = () => { navigator.clipboard?.writeText(addr).then(() => this._toast('已复制'), () => this._toast(addr)); };
    $('iwl-switch').onclick = () => c.request('profile', { team: me.team === 0 ? 1 : 0 }).then((d) => c._applyRoom(d.room)).catch((e) => this._toast(e.message));
    $('iwl-weapon').onchange = (e) => { this.game.api.setLoadout({ weapon: e.target.value }); c.request('profile', { weapon: e.target.value }).then((d) => c._applyRoom(d.room)).catch(() => {}); };
    const setS = (k, v) => c.request('settings', { settings: { [k]: v } }).then((d) => c._applyRoom(d.room)).catch((e) => this._toast(e.message));
    if (host) {
      $('iwl-map').onchange = (e) => setS('mapId', e.target.value);
      $('iwl-dur').onchange = (e) => setS('duration', +e.target.value);
      $('iwl-diff').onchange = (e) => setS('difficulty', e.target.value);
      $('iwl-start').onclick = () => this._hostStart();
    }
    $('iwl-leave').onclick = () => { this.leave(); this._entry(); };
  }

  async _hostStart() {
    const c = this.client;
    try { await c.request('start'); } catch (e) { return this._toast(e.message); }
    const pkt = this.session.buildStart(c.room.settings);
    this.session.send(pkt);
    this._launch(pkt);
  }

  _launch(d) {
    this.hide();
    this.game.startMatch({ mapId: d.mapId, duration: d.duration, difficulty: d.difficulty, palette: d.palette, roster: d.roster, net: this.session });
  }

  // 一局结束后回到房间
  back() {
    this.session?.detach();
    if (this.client?.isHost) this.client.request('end').catch(() => {});
    this.open();
  }

  _drop() {
    this.session?.close();
    this.session = null; this.client = null; G.net = null;
    history.replaceState(null, '', location.pathname + location.search);
  }
  leave() { if (this.client) this._drop(); }

  _toast(msg) {
    const t = document.createElement('div');
    t.className = 'iwl-toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  }
}
