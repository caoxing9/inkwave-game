# INKWAVE — 10-Player LAN Edition

Run `node server.mjs` (Node 18+) and have every player open the same server address. In the multiplayer lobby, choose **LAN server**. Up to 10 players, 5 per team; bots fill empty slots. Supports direct WebRTC connections with an HTTP relay fallback. The online WSS mode requires an INKWAVE-compatible server.

## 中文

运行 `node server.mjs`（Node 18+），所有玩家打开同一服务器地址，在联机大厅选择「局域网服务器」。最多 10 人，每队 5 人，空位由机器人补齐；支持 WebRTC 直连与 HTTP 中转。在线 WSS 模式需要墨浪兼容服务器。
