// INKWAVE LAN multiplayer server (zero dependencies, Node 18+)
//
//   node server.mjs [port]        default 3000
//
// 1. Serves the game's static files (this directory).
// 2. /api/rooms: in-memory rooms + WebRTC signaling exchange + HTTP fallback relay (game data goes through the server when direct connections fail).
//    Players prefer direct WebRTC (a star centered on the host); the server only exchanges SDP/ICE while connecting.
//
// Every player must open the same server address: http://<this computer's LAN IP>:3000
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.argv[2] || process.env.PORT || 3000);
const MAX_MEMBERS = 10;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.ico': 'image/x-icon', '.wasm': 'application/wasm', '.txt': 'text/plain; charset=utf-8',
};

// ---------------------------------------------------------------------------------------------- rooms
/** code → { code, host, members[], signals[], seq, started, updated, settings, relay:Set, packets[], packetSeq, lastPacket{} } */
const rooms = new Map();

const cleanName = (v) => (typeof v === 'string' ? v.replace(/[^\p{L}\p{N}_ .-]/gu, '').trim().slice(0, 16) : '');
const WEAPONS = new Set(['shooter', 'roller', 'charger', 'blaster']);
const publicRoom = (r) => ({
  code: r.code, host: r.host, started: r.started, settings: r.settings, relayMembers: [...r.relay],
  members: r.members.map(({ id, name, team, weapon }) => ({ id, name, team, weapon })),
});

function cleanup() {
  const now = Date.now();
  for (const [code, r] of rooms) {
    const hostAlive = r.members.some((m) => m.id === r.host && now - m.seen < 10000);
    if (now - r.updated > 30 * 60000 || !hostAlive) { rooms.delete(code); continue; }
    r.members = r.members.filter((m) => now - m.seen < 10000);
  }
}
function auth(r, id, token) {
  return r.members.find((m) => m.id === id && m.token.length === token.length && timingSafeEqual(Buffer.from(m.token), Buffer.from(token)));
}
function balancedTeam(r) {
  const a = r.members.filter((m) => m.team === 0).length, b = r.members.filter((m) => m.team === 1).length;
  return a <= b ? 0 : 1;
}

function handleRooms(body) {
  cleanup();
  const b = body || {};
  if (b.action === 'create' || b.action === 'join') {
    const name = cleanName(b.name);
    if (!name) return [400, { error: 'Please enter a nickname' }];
    const member = { id: randomUUID(), token: randomBytes(24).toString('hex'), name, team: 0, weapon: WEAPONS.has(b.weapon) ? b.weapon : 'shooter', seen: Date.now() };
    let room;
    if (b.action === 'create') {
      if (rooms.size >= 100) return [429, { error: 'Too many rooms right now. Please try again later' }];
      let code;
      do { code = randomBytes(2).toString('hex').toUpperCase(); } while (rooms.has(code));
      room = { code, host: member.id, members: [member], signals: [], seq: 0, started: false, updated: Date.now(),
        settings: { mapId: 'tidewater', duration: 180, difficulty: 'normal' }, relay: new Set(), packets: [], packetSeq: 0, lastPacket: {} };
      rooms.set(code, room);
    } else {
      room = rooms.get(String(b.code || '').trim().toUpperCase());
      if (!room) return [404, { error: 'Room not found or closed. Check the room code' }];
      if (room.started) return [409, { error: 'The match has already started. Please wait for it to end' }];
      if (room.members.length >= MAX_MEMBERS) return [409, { error: `The room is full (${MAX_MEMBERS} players)` }];
      member.team = balancedTeam(room);
      room.members.push(member);
    }
    room.updated = Date.now();
    return [200, { room: publicRoom(room), id: member.id, token: member.token }];
  }

  const room = rooms.get(String(b.code || ''));
  if (!room) return [404, { error: 'The room is closed. Go back to the lobby and create a new one' }];
  const me = auth(room, String(b.id || ''), String(b.token || ''));
  if (!me) return [403, { error: 'Your room session has expired' }];
  me.seen = room.updated = Date.now();
  const isHost = me.id === room.host;

  switch (b.action) {
    case 'poll': break;
    case 'signal': {
      // star topology: host ↔ each member only
      if (!room.members.some((m) => m.id === b.to) || (!isHost && b.to !== room.host)) return [400, { error: 'Invalid connection target' }];
      room.signals.push({ seq: ++room.seq, from: me.id, to: b.to, data: b.data });
      if (room.signals.length > 1024) room.signals = room.signals.slice(-1024);
      break;
    }
    case 'fallback': {
      const target = isHost ? b.to : me.id;
      if (target === room.host || !room.members.some((m) => m.id === target)) return [400, { error: 'Invalid relay target' }];
      room.relay.add(target);
      break;
    }
    case 'profile': {
      if (b.name) me.name = cleanName(b.name) || me.name;
      if (WEAPONS.has(b.weapon)) me.weapon = b.weapon;
      if (b.team === 0 || b.team === 1) {
        if (room.members.filter((m) => m.team === b.team && m !== me).length >= 5) return [409, { error: 'That team is full (5 players)' }];
        me.team = b.team;
      }
      break;
    }
    case 'settings': {
      if (!isHost) return [403, { error: 'Only the host can change match settings' }];
      const s = b.settings || {};
      if (typeof s.mapId === 'string') room.settings.mapId = s.mapId.slice(0, 32);
      if ([90, 180].includes(s.duration)) room.settings.duration = s.duration;
      if (['easy', 'normal', 'hard'].includes(s.difficulty)) room.settings.difficulty = s.difficulty;
      break;
    }
    case 'start': if (!isHost) return [403, { error: 'Only the host can start the match' }]; room.started = true; break;
    case 'end': if (isHost) room.started = false; break;
    case 'leave':
      if (isHost) rooms.delete(room.code);
      else { room.members = room.members.filter((m) => m.id !== me.id); room.relay.delete(me.id); }
      return [200, { ok: true }];
    default: return [400, { error: 'Unknown action' }];
  }

  // ---- HTTP fallback relay: clients submit packets for (or via) the host with each poll, and fetch their own packets on the next poll
  if (b.action === 'poll') {
    const incoming = Array.isArray(b.packets) ? b.packets : [];
    if (incoming.length > 64) return [400, { error: 'Too many relay messages' }];
    const since = Number(b.packetSince) || 0;
    const now = Date.now();
    room.packets = room.packets.filter((p) => now - p.at < 30000 && !(p.to === me.id && p.seq <= since));
    for (const p of incoming) {
      if (!Number.isSafeInteger(p?.id) || p.id <= (room.lastPacket[me.id] || 0)) continue;   // dedupe retries
      room.lastPacket[me.id] = p.id;
      const peer = isHost ? p.to : me.id;
      if (typeof p.to !== 'string' || (!isHost && p.to !== room.host) || !room.relay.has(peer)) continue;
      if (!room.members.some((m) => m.id === p.to)) continue;
      room.packets.push({ seq: ++room.packetSeq, from: me.id, to: p.to, data: p.data, at: now });
    }
    if (room.packets.length > 4096) room.packets = room.packets.slice(-4096);
  }
  const packets = room.packets.filter((p) => p.to === me.id && p.seq > (Number(b.packetSince) || 0)).slice(0, 128);
  return [200, {
    room: publicRoom(room), seq: room.seq,
    signals: room.signals.filter((s) => s.to === me.id && s.seq > (Number(b.since) || 0)),
    packets, packetSeq: packets.length ? packets[packets.length - 1].seq : Number(b.packetSince) || 0,
  }];
}

// ---------------------------------------------------------------------------------------------- http
function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/api/rooms') {
    if (req.method === 'GET') return send(res, 200, JSON.stringify({ multiplayer: true, mode: 'lan-server' }), { 'Content-Type': 'application/json' });
    if (req.method !== 'POST') return send(res, 405, '');
    let raw = '';
    req.on('data', (c) => { raw += c; if (raw.length > 200000) req.destroy(); });
    req.on('end', () => {
      let status, out;
      try { [status, out] = handleRooms(JSON.parse(raw || '{}')); } catch { [status, out] = [400, { error: 'Invalid request format' }]; }
      send(res, status, JSON.stringify(out), { 'Content-Type': 'application/json' });
    });
    return;
  }
  // static files
  let p = decodeURIComponent(url.pathname);
  if (p.endsWith('/')) p += 'index.html';
  const file = path.normalize(path.join(ROOT, p));
  if (!file.startsWith(ROOT) || path.basename(file).startsWith('.') || file.endsWith('.mjs') && path.basename(file) === 'server.mjs') return send(res, 403, 'forbidden');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'not found');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-cache' });
    fs.createReadStream(file).pipe(res);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  console.log(`\nINKWAVE multiplayer server started`);
  console.log(`  Local:    http://localhost:${PORT}`);
  for (const ip of ips) console.log(`  LAN:      http://${ip}:${PORT}   ← share this address with friends on the same network`);
  console.log('\nAllow this port through your firewall. Press Ctrl+C to stop.\n');
});
